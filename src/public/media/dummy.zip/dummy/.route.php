<?php


// simple routing
routing([
    '/dummy' => 'dummy/index@index',
]);
