<?php
class testmoduleinstallation_model_test {
    function get_model() {
            return _rp(__FILE__);
    }
}
