<?php
class testmoduleinstallation_indexController extends _system_defaultController
{
    public function indexAction()
    {
        $rs['file'] = _factory('testmoduleinstallation_model_test')->get_model();
        return array('data' => ['rs'=>$rs]);  //data show in view as $rs
    }
}
